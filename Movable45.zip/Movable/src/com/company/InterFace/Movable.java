package com.company.InterFace;

public interface Movable {
     void move();

     int getPrice();
}
