package com.company;

import java.util.Calendar;

import com.company.InterFace.Movable;
import com.company.Store.Store;
import com.company.Equipment.*;


public class Main {


    public static void main(String[] args) {

            Calendar calendar = Calendar.getInstance();
            calendar.set(2000, Calendar.FEBRUARY, 3);

            Car myCar = new PassengerCar(CarBrand.MAZDA,"Mazda 6",147,"White",calendar.getTime(),5000,5);

            Calendar calendar1 = Calendar.getInstance();
            calendar1.set(2018, Calendar.MARCH, 3);

            Car myCar1 = new PassengerCar(CarBrand.BMW,"BMW X5",149,"Black",calendar1.getTime(),6000,5);

            Calendar calendar2 = Calendar.getInstance();
            calendar2.set(2008, Calendar.OCTOBER, 3);

            Car myCar2 = new PassengerCar(CarBrand.MERCEDES,"Mercedes Benz",256,"Grey",calendar2.getTime(),4500,5);

  //          System.out.println(myCar.toString());

            Movable Bike = new Bike(1,4000, new Bike.Carriage(255),true);
            Bike.move();
            Bike.move();
  //          System.out.println(Bike.toString());

            Movable Robot = new Robot();
            Robot.move();
            ((com.company.Equipment.Robot) Robot).moveRight();
            ((Robot) Robot).moveLeft();

            Calendar calendar3 = Calendar.getInstance();
            calendar3.set(2014, Calendar.JULY, 20);

            Movable FreightTrain = new FreightTrain(CarBrand.MAZDA,"Mazda",185,"Grey",calendar3.getTime(),8000,1000,true,12,new FreightTrain.RailwayCarriage(200));
            FreightTrain.move();
            ((com.company.Equipment.FreightTrain) FreightTrain).brake();
            System.out.println(FreightTrain.toString());


            Store<Car> carStore = new Store<>("Car Store", (Car) myCar, (Car) myCar1, (Car) myCar2);
            carStore.printProducts();
            carStore.purchase(1, 5000);
            carStore.sell((Car) myCar2, 4500);
            System.out.println();
            carStore.printProducts();




    }
}


