package com.company.Store;

import com.company.InterFace.Movable;
import java.lang.reflect.Array;

public class Store <T extends Movable> {

    private String nameOfStore;
    private T[] productsList;
    private T[] tempArray;
    private int amountOfProduct;
    private double amountOfMoneyInCass = 100000;

    public Store(String nameOfStore, T... product){
        this.nameOfStore = nameOfStore;
        this.productsList = product;
        amountOfProduct = productsList.length;
    }

    public Store(String nameOfStore, double amountOfMoneyInCass, T... product){
        this.nameOfStore = nameOfStore;
        this.amountOfMoneyInCass = amountOfMoneyInCass;
        this.productsList = product;
        amountOfProduct = productsList.length;
    }

    public void sell(T product, double price) {
        if (price <= product.getPrice() && amountOfMoneyInCass >= price) {
            Class<T> tClass = (Class<T>) product.getClass();
            createTempArray(tClass, productsList.length + 1);
            System.arraycopy(productsList, 0, tempArray, 0, productsList.length);
            tempArray[productsList.length] = product;
            productsList = tempArray;
            amountOfMoneyInCass -= price;
            System.out.println("The " + product.getClass().getSimpleName() + " is successfuly sold out!");
        } else {
            System.out.println("The store can't buy this product!");
        }
    }

    public void purchase(int positionInList, double money) {
        if (positionInList - 1 < 0 || positionInList - 1 >= productsList.length) {
            System.out.println("There are no products under this number.");
        } else {
            Class<T> tClass = (Class<T>) productsList[positionInList - 1].getClass();
            if (money >= productsList[positionInList - 1].getPrice()) {
                int j = 0;
                createTempArray(tClass, productsList.length - 1);
                for (int i = 0; i < productsList.length; i++) {
                    if (i == positionInList - 1) {
                        continue;
                    }
                    tempArray[j] = productsList[i];
                    j++;
                }
                amountOfMoneyInCass += productsList[positionInList - 1].getPrice();
                productsList = tempArray;
            } else {
                System.out.println("You are offering not enough money.");
            }
        }
    }

    public void createTempArray(Class<T> tClass, int length) {
        tempArray = (T[]) Array.newInstance(tClass, length);
    }

    public void printProducts() {
        if (amountOfProduct == 0) {
            System.out.println("There are no products in the store.");
        } else {
            for (int i = 0; i < productsList.length; i++) {
                int j = i + 1;
                System.out.println(j + ". " + productsList[i].getClass().getSimpleName() + ". " +
                        productsList[i].toString() + "\nIt costs - " + productsList[i].getPrice());
            }
        }
    }

    public String getNameOfStore() {
        return nameOfStore;
    }

    public void setNameOfStore(String nameOfStore) {
        this.nameOfStore = nameOfStore;
    }

    private int getAmountOfProduct() {
        return amountOfProduct;
    }

    public double getAmountOfMoneyInCass() {
        return amountOfMoneyInCass;
    }

    public void setAmountOfMoneyInCass(int amountOfMoneyInCass) {
        this.amountOfMoneyInCass = amountOfMoneyInCass;
    }
}

