package com.company.Equipment;

import java.util.Date;

public class FreightTrain extends Car {

    private int liftingCapacity;
    private boolean isHasRailwayCarriage;
    private int maxAmountOfRailwayCarriage;
    private RailwayCarriage railwayCarriage;

    protected FreightTrain() {
        super();
    }

    public FreightTrain(CarBrand carBrand, String name, int carId, String color, Date dateOfIssue, int price, int liftingCapacity, boolean isHasRailwayCarriage, int maxAmountOfRailwayCarriage, RailwayCarriage railwayCarriage) {
        super(carBrand, name, carId, color, dateOfIssue, price);
        this.liftingCapacity = liftingCapacity;
        this.isHasRailwayCarriage =isHasRailwayCarriage;
        this.maxAmountOfRailwayCarriage = maxAmountOfRailwayCarriage;
        this.railwayCarriage = railwayCarriage;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("FreightTrain{");
        sb.append("carBrand=").append(carBrand);
        sb.append(", name='").append(name).append('\'');
        sb.append(", carId=").append(carId);
        sb.append(", color='").append(color).append('\'');
        sb.append(", dateOfIssue=").append(dateOfIssue);
        sb.append(", isRide=").append(isRide);
        sb.append(", price=").append(price);
        sb.append(", liftingCapacity=").append(liftingCapacity);
        sb.append(", isHasRailwayCarriage=").append(isHasRailwayCarriage);
        sb.append(", maxAmountOfRailwayCarriage=").append(maxAmountOfRailwayCarriage);
        sb.append(", railwayCarriage=").append(railwayCarriage);
        sb.append('}');
        return sb.toString();
    }

    @Override
    public void brake() {
        System.out.println("The car is stopped!");
    }

    @Override
    public void move() {
        System.out.println("The FreightTrain is start!");
    }

    @Override
    public int getPrice() {
        return price;
    }

    public static class RailwayCarriage {

        private final int CAPACITY_OF_RAILWAY_CARRIAGE;
        private final int WEIGHT_OF_RAILWAY_CARRIAGE;
        private String nameOnRailwayCarriage;
        private int numberRailwayCarriage;
        private int weightOfCargo;


        public RailwayCarriage(int weight_of_railway_carriage) {
            WEIGHT_OF_RAILWAY_CARRIAGE = 200;
            nameOnRailwayCarriage = "";
            numberRailwayCarriage = 5555;
            CAPACITY_OF_RAILWAY_CARRIAGE = 4000;
            weightOfCargo = 0;
        }

        public RailwayCarriage(String nameOnRailwayCarriage, int numberRailwayCarriage, int capacityOfRailwayCarriage,
                               int weight_of_railway_carriage, int weightOfCargo) {
            this.nameOnRailwayCarriage = nameOnRailwayCarriage;
            this.numberRailwayCarriage = numberRailwayCarriage;
            this.CAPACITY_OF_RAILWAY_CARRIAGE = capacityOfRailwayCarriage;
            this.WEIGHT_OF_RAILWAY_CARRIAGE = weight_of_railway_carriage;
            this.weightOfCargo = weightOfCargo;
        }

        public String getNameOnRailwayCarriage() {
            return nameOnRailwayCarriage;
        }

        public void setNameOnRailwayCarriage(String nameOnRailwayCarriage) {
            this.nameOnRailwayCarriage = nameOnRailwayCarriage;
        }

        public int getNumberRailwayCarriage() {
            return numberRailwayCarriage;
        }

        public void setNumberRailwayCarriage(int numberRailwayCarriage) {
            this.numberRailwayCarriage = numberRailwayCarriage;
        }

        public int getCAPACITY_OF_RAILWAY_CARRIAGE() {
            return CAPACITY_OF_RAILWAY_CARRIAGE;
        }

        public int getWEIGHT_OF_RAILWAY_CARRIAGE() {
            return WEIGHT_OF_RAILWAY_CARRIAGE;
        }

        public int getWeightOfCargo() {
            return weightOfCargo;
        }

        public void setWeightOfCargo(int weightOfCargo) {
            if (weightOfCargo > CAPACITY_OF_RAILWAY_CARRIAGE) {
                System.out.println("You can't load in railway carriage this cargo!");
            } else {
                this.weightOfCargo = weightOfCargo;
            }

        }
    }
}