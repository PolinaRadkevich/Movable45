package com.company.Equipment;

import java.util.Date;


public class PassengerCar extends Car {

    private int placesAmount = 5;

    protected PassengerCar(){
        super();
}
    public PassengerCar(CarBrand carBrand, String name, int carId, String color, Date dateOfIssue, int price, int placesAmount){
        super(carBrand, name,carId,color,dateOfIssue, price);
        this.placesAmount=placesAmount;

        }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("PassengerCar{");
        sb.append("carBrand=").append(carBrand);
        sb.append(", name='").append(name).append('\'');
        sb.append(", carId=").append(carId);
        sb.append(", color='").append(color).append('\'');
        sb.append(", productionDate=").append(dateOfIssue);
        sb.append(", isRide=").append(isRide);
        sb.append(", price=").append(price);
        sb.append(", placesAmount=").append(placesAmount);
        sb.append('}');
        return sb.toString();
    }

    @Override
    public void move() {System.out.println("The car is start!");
    }

    @Override
    public int getPrice() {
        return price;
    }
}

