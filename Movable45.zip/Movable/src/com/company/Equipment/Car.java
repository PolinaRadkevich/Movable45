package com.company.Equipment;

import com.company.InterFace.Movable;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Objects;


public abstract class Car implements Movable {

    protected final String DATE_PATTERN = "dd.MM.YYYY";
    protected CarBrand carBrand;
    protected String name;
    protected int carId;
    protected String color;
    protected Date dateOfIssue;
    protected boolean isRide;
    protected SimpleDateFormat simpleDateFormat = new SimpleDateFormat(DATE_PATTERN);
    protected StringBuilder stringBuilder;
    protected int price;


    public Car(CarBrand carBrand, String name, int carId, String color, Date dateOfIssue, int price) {
        this.carBrand = carBrand;
        this.name = name;
        this.carId = carId;
        this.color = color;
        this.dateOfIssue = dateOfIssue;
        this.price = price;
    }

    public Car() {

    }

    @Override
    public abstract void move();

    public void brake() {
        isRide = false;
        System.out.println("The car is stopped!");
    }
    @Override
    public String toString() {
        stringBuilder = new StringBuilder("The name of this car is ");
        return stringBuilder.append(name).append(", number ").append(carId).append(", it is ").
                append(color).append(".\nCar brand - ").append(carBrand.getName()).
                append(". Manufactured ").append(getDateOfIssue()).toString();
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Car)) return false;
        Car car = (Car) o;
        return carId == car.carId && isRide == car.isRide && carBrand == car.carBrand && Objects.equals(name, car.name) && Objects.equals(color, car.color) && Objects.equals(dateOfIssue, car.dateOfIssue);
    }

    @Override
    public int hashCode() {
        return Objects.hash(carBrand, name, carId, color, dateOfIssue, isRide);
    }

    @Override
    public int getPrice() {
        return price;
    }

    public void setPrice(int price){
        this.price = price;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getCarId() {
        return carId;
    }

    public void setCarId(int carId) {
        this.carId = carId;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getDateOfIssue(){
        final String DATE_FORMAT = "yyyy.MMMM.dd";
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy.MMMM.dd");
        String formattedDate = simpleDateFormat.format(dateOfIssue);
        return formattedDate;
    }
}


