package com.company.Equipment;


import com.company.InterFace.Movable;

public class Robot implements Movable {

    int price;

    public void moveRight() {
        System.out.println("Робот поворачивает вправо.");
    }

    public void moveLeft() {
        System.out.println("Робот поворачивает влево.");
    }

    @Override
    public void move(){ System.out.println("Робот двигается");
    }

    @Override
    public int getPrice() {
        return price;
    }
}


