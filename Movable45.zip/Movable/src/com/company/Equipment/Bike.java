package com.company.Equipment;

import com.company.InterFace.Movable;

public class Bike implements Movable {

    private int speedPosition;
    private int price;
    private Carriage carriage;
    private boolean isHasCarriage;

    public Bike(int speedPosition, int price, Carriage carriage, boolean isHasCarriage){
        this.speedPosition = speedPosition;
        this.price = price;
        this.carriage =carriage;
        this.isHasCarriage = true;
    }

    public void move() {
        speedPosition++;
        System.out.println("Actual speed is: " + speedPosition);
    }

    public void move(int value) {
        speedPosition += value;
        System.out.println("Bike speed now is: " + speedPosition + "(greater on " + value + ")");
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("Bike{");
        sb.append("speedPosition=").append(speedPosition);
        sb.append(", price=").append(price);
        sb.append(", carriage=").append(carriage);
        sb.append(", isHasCarriage=").append(isHasCarriage);
        sb.append('}');
        return sb.toString();
    }

    @Override
    public int getPrice() {
        return price;
    }

    public static class Carriage {

        private int carriageVolume;

        public Carriage(int carriageVolume) {
            this.carriageVolume = carriageVolume;
        }

        public int getCarriageVolume() {
            return carriageVolume;
        }

        public void setCarriageVolume(int carriageVolume) {
            this.carriageVolume = carriageVolume;
        }
    }
}

